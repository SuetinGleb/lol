import sqlite3
from collections import namedtuple
from data import __all_models, db_session
from data.users import User, RegisterForm, LoginForm
from data.trains import Train, TrainResource, TrainListResource
from data.food import Food, FoodResource, FoodListResource
from flask_login import LoginManager, logout_user, login_user, login_required, current_user
from flask import Flask, render_template, redirect, url_for, request, g

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'
login_manager = LoginManager()
login_manager.init_app(app)

Message = namedtuple('Message', "id author name subject date yeartown number\
    quantity price notes clas decomission numberinlist publisher sum set_1 consignment")
messages = []
found = []
M = tuple()


@login_manager.user_loader
def load_user(user_id):
    session = db_session.create_session()
    return session.query(User).get(user_id)


@app.route("/main", methods=["GET"])
@app.route("/", methods=["GET"])
def main():
    return render_template("index.html")


@app.route('/register', methods=['GET', 'POST'])
def reqister():
    form = RegisterForm()
    if form.validate_on_submit():
        if form.password.data != form.password_again.data:
            return render_template('register.html', title='Регистрация',
                                   form=form,
                                   message="Пароли не совпадают")
        session = db_session.create_session()
        if session.query(User).filter(User.email == form.email.data).first():
            return render_template('register.html', title='Регистрация',
                                   form=form,
                                   message="Такой пользователь уже есть")
        name = form.name.data
        surname = form.surname.data
        user = User(
            email=form.email.data,
            name=name,
            surname=surname,
            height=float(form.height.data),
            weight=float(form.weight.data),
            age=int(form.age.data)
        )
        user.set_password(form.password.data)
        session.add(user)
        session.commit()
        return redirect('/login')
    return render_template('register.html', title='Регистрация', form=form)


@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        session = db_session.create_session()
        user = session.query(User).filter(User.email == form.email.data).first()
        if user and user.check_password(form.password.data):
            login_user(user, remember=form.remember_me.data)
            return redirect("/")
        return render_template('login.html',
                               message="Неправильный логин или пароль",
                               form=form)
    return render_template('login.html', title='Авторизация', form=form)


@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect("/")


@app.route("/training")
def training():
    con = sqlite3.connect('BD1.db')
    cursoro = con.cursor()
    show_all = cursoro.execute('SELECT * FROM trains').fetchall()
    con.commit()
    con.close()
    return render_template("index2.html", show_all=show_all)


@app.route("/add1", methods=["GET"])
def add1():
    if not current_user.is_authenticated:
        return redirect('/training')
    trains = TrainListResource.get(TrainListResource())
    return render_template("add1.html", trains=trains)


@app.route('/add_train', methods=["POST"])
def add_train():
    if not current_user.is_authenticated:
        return redirect('/training')
    name = request.form["name"]
    group = request.form["group"]
    opis = request.form["opis"]
    kol = request.form["kol"]
    time = request.form["time"]
    train = Train(
        name=name,
        group=group,
        opis=opis,
        kol=kol,
        time=time
    )
    session = db_session.create_session()
    session.add(train)
    session.commit()
    return redirect('/add1')


@app.route("/delete1", methods=["GET"])
def delete1():
    if not current_user.is_authenticated:
        return redirect('/training')
    trains = TrainListResource.get(TrainListResource())
    return render_template("delete1.html", trains=trains)


@app.route("/delete1/<train_id>", methods=["GET", "POST"])
def delete_it(train_id):
    if not current_user.is_authenticated:
        return redirect('/training')
    else:
        TrainResource.delete(TrainResource(), train_id)
        return redirect('/delete1')


@app.route("/error", methods=["GET"])
def error():
    return render_template('error.html', M=M)


@app.route("/food")
def food():
    con = sqlite3.connect('BD1.db')
    cursoro = con.cursor()
    show_all = cursoro.execute('SELECT * FROM food').fetchall()
    con.commit()
    con.close()
    return render_template("index2food.html", show_all=show_all)


@app.route("/add1food", methods=["GET"])
def add1food():
    if not current_user.is_authenticated:
        return redirect('/food')
    food = FoodListResource.get(FoodListResource())
    return render_template("add1food.html", food=food)


@app.route('/add_food', methods=["POST"])
def add_food():
    if not current_user.is_authenticated:
        return redirect('/food')
    name = request.form["name"]
    kall = request.form["kall"]
    ingr = request.form["ingr"]
    time = request.form["time"]
    food = Food(
        name=name,
        kall=kall,
        ingr=ingr,
        time=time
    )

    session = db_session.create_session()
    session.add(food)
    session.commit()
    return redirect('/add1food')


@app.route("/delete1food", methods=["GET"])
def delete1food():
    if not current_user.is_authenticated:
        return redirect('/food')
    food = FoodListResource.get(FoodListResource())
    return render_template("delete1food.html", food=food)


@app.route("/delete1food/<food_id>", methods=["GET", "POST"])
def delete_food(food_id):
    if not current_user.is_authenticated:
        return redirect('/food')
    FoodResource.delete(FoodResource(), food_id)
    return redirect('/food')


if __name__ == "__main__":
    db_session.global_init("BD1.db")
    app.run(port='8089', host="127.0.0.1")
