from .db_session import create_session, global_init

global_init("BD1.db")
