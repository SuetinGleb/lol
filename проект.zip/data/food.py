from pickle import loads, dumps
from flask import jsonify
from flask_restful import reqparse, abort, Resource
from .db_session import SqlAlchemyBase, create_session
import sqlalchemy


def abort_if_food_not_found(food_id):
    session = create_session()
    food = session.query(Food).get(food_id)
    if not food:
        abort(404, message=f"Food {food_id} not found")


class Food(SqlAlchemyBase):
    __tablename__ = 'food'

    id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True, autoincrement=True)
    name = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    kall = sqlalchemy.Column(sqlalchemy.Integer, nullable=True)
    ingr = sqlalchemy.Column(sqlalchemy.String, index=True, unique=True, nullable=True)
    time = sqlalchemy.Column(sqlalchemy.Integer, nullable=True)


class FoodResource(Resource):
    def get(self, food_id):
        session = create_session()
        food = session.query(Food).get(food_id)
        return food

    def delete(self, food_id):
        abort_if_food_not_found(food_id)
        session = create_session()
        food = session.query(Food).get(food_id)
        session.delete(food)
        session.commit()
        return jsonify({'success': 'OK'})


class FoodListResource(Resource):
    def get(self):
        session = create_session()
        food = session.query(Food).all()
        return food

