from pickle import loads, dumps
from flask import jsonify
from flask_restful import reqparse, abort, Resource
from .db_session import SqlAlchemyBase, create_session
import sqlalchemy


def abort_if_train_not_found(train_id):
    session = create_session()
    train = session.query(Train).get(train_id)
    if not train:
        abort(404, message=f"Train {train_id} not found")


class Train(SqlAlchemyBase):
    __tablename__ = 'trains'

    id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True, autoincrement=True)
    name = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    group = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    opis = sqlalchemy.Column(sqlalchemy.String, index=True, unique=True, nullable=True)
    kol = sqlalchemy.Column(sqlalchemy.Integer, nullable=True)
    time = sqlalchemy.Column(sqlalchemy.Integer, nullable=True)


class TrainResource(Resource):
    def get(self, train_id):
        session = create_session()
        train = session.query(Train).get(train_id)
        return train

    def delete(self, train_id):
        abort_if_train_not_found(train_id)
        session = create_session()
        train = session.query(Train).get(train_id)
        session.delete(train)
        session.commit()
        return jsonify({'success': 'OK'})


class TrainListResource(Resource):
    def get(self):
        session = create_session()
        train = session.query(Train).all()
        return train

